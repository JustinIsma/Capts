import requests

# Function to get weather forecast data
def get_weather_forecast(city):
    api_key = '980ad41772531b4c817d317324c0cbea'  # Replace with your actual API key
    url = f'http://api.openweathermap.org/data/2.5/forecast?q={city}&appid={api_key}&units=metric'
    
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        print(f'Weather forecast for {city}:\n')
        
        for forecast in data['list']:
            date_time = forecast['dt_txt']
            temp = forecast['main']['temp']
            description = forecast['weather'][0]['description']
            print(f'Date & Time: {date_time}, Temperature: {temp} °C, Description: {description}')
    else:
        print('Error fetching weather forecast data')

# Main function to run the program
if __name__ == "__main__":
    city = input("Enter city name: ")
    get_weather_forecast(city)