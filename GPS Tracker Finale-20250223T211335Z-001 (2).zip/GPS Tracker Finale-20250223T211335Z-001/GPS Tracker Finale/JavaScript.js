let map;
let weatherData = {};

function initMap() {
    // Initialize the map centered at an arbitrary default location (e.g., Paris).
    map = L.map('map').setView([48.8584, 2.2945], 13);

    // Set up the OpenStreetMap tile layer.
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://us1.locationiq.com/v1/reverse?key=pk.89aede49783d41a024b13a2f58758528&lat=51.505150&lon=-0.12188386&format=json&">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Add a click event to get coordinates when the user clicks on the map.
    map.on('click', function (e) {
        const lat = e.latlng.lat;
        const lon = e.latlng.lng;
        getAddress(lat, lon);  // Fetch the address from LocationIQ API
        getWeather(lat, lon);  // Fetch weather from OpenWeatherMap API
    });
}

// Fetch the address based on coordinates from LocationIQ API
function getAddress(lat, lon) {
    const apiKey = 'pk.89aede49783d41a024b13a2f58758528';
    const url = `https://us1.locationiq.com/v1/reverse?key=pk.89aede49783d41a024b13a2f58758528&lat=51.505150&lon=-0.12188386&format=json&`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            const address = data.display_name;
            document.getElementById('address').innerHTML = `<h2>Address:</h2><p>${address}</p>`;
        })
        .catch(error => console.error('Error fetching address:', error));
}

// Fetch weather data from OpenWeatherMap API based on coordinates
function getWeather(lat, lon) {
    const apiKey = '980ad41772531b4c817d317324c0cbea';
    const url = `https://us1.locationiq.com/v1/reverse?key=pk.89aede49783d41a024b13a2f58758528&lat=51.505150&lon=-0.12188386&format=json&`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            weatherData = data;
            const mainWeather = data.list[0].main;
            const description = data.list[0].weather[0].description;
            const temp = mainWeather.temp;
            const humidity = mainWeather.humidity;
            const wind = data.list[0].wind.speed;

            // Display weather data in the designated area
            document.getElementById('weather').innerHTML = `
                <h2>Weather Information:</h2>
                <p>Temperature: ${temp} °C</p>
                <p>Condition: ${description}</p>
                <p>Humidity: ${humidity}%</p>
                <p>Wind Speed: ${wind} m/s</p>
            `;
        })
        .catch(error => console.error('Error fetching weather data:', error));
}

// Call the function to initialize the map when the page loads
window.onload = initMap;
